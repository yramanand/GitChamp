Bootstraps EC2 instances by retrieving and processing the Metadata block of a CloudFormation resource.


